#include <gtk/gtk.h>


void
on_btnconnexion_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_btninscription_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_btnfermer_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_btnconnecter_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_btnretour_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_btngestionclient_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_btngestionvols_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_btngestionrestaurant_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_btngestionhebergement_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_btngestionlocationvoiture_clicked   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button13_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_btnagenttesting_clicked             (GtkButton       *button,
                                        gpointer         user_data);
