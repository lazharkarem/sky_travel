#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"


void
on_btnconnexion_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *window;

window1=lookup_widget(button,"windowaccueil");
gtk_widget_destroy(window1);
window=create_windowconnexion();
gtk_widget_show (window);

}

void
on_btninscription_clicked              (GtkButton       *button,
                                        gpointer         user_data)


{
GtkWidget *window1;
GtkWidget *window;

window1=lookup_widget(button,"windowaccueil");
gtk_widget_destroy(window1);
window=create_windowinscription();
gtk_widget_show (window);

}





void
on_btnfermer_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_main_quit();
}


void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{


}


void
on_btnconnecter_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *window;

window1=lookup_widget(button,"windowinscription");
gtk_widget_destroy(window1);
window=create_windowadmin();
gtk_widget_show (window);
}


void
on_btnretour_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *window;

window1=lookup_widget(button,"windowinscription");
gtk_widget_destroy(window1);
window=create_windowaccueil();
gtk_widget_show (window);

}


void
on_btngestionclient_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_btngestionvols_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_btngestionrestaurant_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_btngestionhebergement_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_btngestionlocationvoiture_clicked   (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button13_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_btnagenttesting_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *window;

window1=lookup_widget(button,"windowinscription");
gtk_widget_destroy(window1);
window=create_windowagent();
gtk_widget_show (window);

}

